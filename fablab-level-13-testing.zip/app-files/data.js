var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama",
      "name": "panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -0.9171475725212517,
        "pitch": -0.012183058510458977,
        "fov": 1.3031534428056264
      },
      "linkHotspots": [
        {
          "yaw": 0.021284685424733496,
          "pitch": 0.028535332653099488,
          "rotation": 6.283185307179586,
          "target": "1-panorama-2"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.0905688815670267,
          "pitch": -0.15982973288209124,
          "title": "welcome to fablab",
          "text": "this is a test&nbsp;"
        }
      ]
    },
    {
      "id": "1-panorama-2",
      "name": "panorama (2)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -1.1242616375908714,
        "pitch": -0.051048222916341146,
        "fov": 1.3031534428056264
      },
      "linkHotspots": [
        {
          "yaw": 1.1970906061769,
          "pitch": 0.37407338317854055,
          "rotation": 0,
          "target": "0-panorama"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.4310939907909548,
          "pitch": 0.26578620479218174,
          "title": "Nice Office!",
          "text": "cowork with us today!"
        }
      ]
    }
  ],
  "name": "FabLab Level 13 Testing",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
